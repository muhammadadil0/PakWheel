from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm
from django.contrib import messages
from django.contrib.auth import views as auth_views
def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your account has been created successfully! You can now log in.')
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'users/register.html', {'form': form})
from django.shortcuts import render

def home(request):
    if request.user.is_authenticated:
        return render(request, 'users/home.html')
    


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')
    return auth_views.LoginView.as_view()(request)
