from django.contrib import admin
from django.urls import path, include
from users.views import home  # Import the homepage view

urlpatterns = [
    path('', home, name='home'),  # Add the homepage
    path('admin/', admin.site.urls),
    path('users/', include('users.urls')),
]
